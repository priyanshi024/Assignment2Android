package com.example.moviesearch;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MovieViewModel viewModel;
    private MovieAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText searchField = findViewById(R.id.searchField);
        Button searchButton = findViewById(R.id.searchButton);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Initialize the adapter
        adapter = new MovieAdapter(movie -> {
            if (movie != null) {
                Log.d("MainActivity", "Passing Movie: " + movie.getTitle());
                Intent intent = new Intent(MainActivity.this, MovieDetailsActivity.class);
                intent.putExtra("movie", movie); // Pass the Movie object
                startActivity(intent);
            } else {
                Log.e("MainActivity", "Movie object is null!");
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize the ViewModel
        viewModel = new ViewModelProvider(this).get(MovieViewModel.class);

        // Handle search button click
        searchButton.setOnClickListener(v -> {
            String query = searchField.getText().toString().trim();
            if (!query.isEmpty()) {
                viewModel.searchMovies(query).observe(this, movies -> {
                    if (movies != null && !movies.isEmpty()) {
                        Log.d("SEARCH_RESULT", "Movies found: " + movies.size());
                        adapter.setMovies(movies);
                    } else {
                        Log.e("SEARCH_RESULT", "No movies found.");
                        adapter.setMovies(new ArrayList<>()); // Clear the list
                    }
                });
            } else {
                Log.e("INPUT_ERROR", "Search query is empty.");
            }
        });
    }
}
