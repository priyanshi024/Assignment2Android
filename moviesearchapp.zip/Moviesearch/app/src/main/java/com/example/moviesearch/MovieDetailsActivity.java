package com.example.moviesearch;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
public class MovieDetailsActivity extends AppCompatActivity {

    private static final String TAG = "MovieDetailsActivity";
    private MovieRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        ImageView poster = findViewById(R.id.poster);
        TextView title = findViewById(R.id.title);
        TextView year = findViewById(R.id.year);
        TextView plot = findViewById(R.id.plot);
        Button backButton = findViewById(R.id.backButton);

        repository = new MovieRepository();

        // Get movie from Intent
        Movie movie = (Movie) getIntent().getSerializableExtra("movie");

        if (movie != null) {
            Log.d(TAG, "Movie Retrieved: " + movie.getTitle());

            // Set basic details
            title.setText(movie.getTitle());
            year.setText(movie.getYear());

            Glide.with(this)
                    .load(movie.getPoster())
                    .placeholder(android.R.drawable.ic_menu_gallery)
                    .error(android.R.drawable.ic_menu_report_image)
                    .into(poster);

            // Fetch full movie details using IMDb ID
            repository.getMovieDetails(movie.getImdbID(), new MovieRepository.MovieDetailsCallback() {
                @Override
                public void onSuccess(Movie fullMovie) {
                    if (fullMovie != null) {
                        plot.setText(fullMovie.getPlot());
                    } else {
                        Log.e(TAG, "Full movie details are null.");
                    }
                }

                @Override
                public void onError(String error) {
                    Log.e(TAG, "Error fetching movie details: " + error);
                    plot.setText("Failed to load plot.");
                }
            });
        } else {
            Log.e(TAG, "Movie object is null!");
            plot.setText("No movie details available.");
        }

        backButton.setOnClickListener(v -> finish());
    }
}
