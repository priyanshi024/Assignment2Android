package com.example.moviesearch;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
public interface ApiService {

    // Define the endpoint for searching movies
    @GET("/")
    Call<MovieSearchResponse> searchMovies(
            @Query("apikey") String apiKey,  // API key parameter
            @Query("s") String query        // Movie search query
    );

    // Define the endpoint for fetching movie details by IMDb ID
    @GET("/")
    Call<Movie> getMovieDetails(
            @Query("apikey") String apiKey,
            @Query("i") String imdbId
    );
}