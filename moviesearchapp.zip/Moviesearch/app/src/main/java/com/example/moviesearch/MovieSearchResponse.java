package com.example.moviesearch;
import java.util.List;

public class MovieSearchResponse {
    private List<Movie> Search; // Maps to the "Search" field in the API response

    public List<Movie> getSearch() {
        return Search;
    }

    public void setSearch(List<Movie> search) {
        Search = search;
    }
}


