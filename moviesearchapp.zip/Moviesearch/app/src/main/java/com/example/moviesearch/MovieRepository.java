package com.example.moviesearch;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MovieRepository {
    private static final String BASE_URL = "https://www.omdbapi.com/";
    private static final String API_KEY = "ef34b206"; // Replace with your actual OMDB API key
    private ApiService apiService;

    public MovieRepository() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiService = retrofit.create(ApiService.class);
    }

    // Callback interface for movie details
    public interface MovieDetailsCallback {
        void onSuccess(Movie fullMovie);
        void onError(String error);
    }

    // Method to search movies by query
    public MutableLiveData<List<Movie>> searchMovies(String query) {
        MutableLiveData<List<Movie>> data = new MutableLiveData<>();
        apiService.searchMovies(API_KEY, query).enqueue(new Callback<MovieSearchResponse>() {
            @Override
            public void onResponse(Call<MovieSearchResponse> call, Response<MovieSearchResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("MovieRepository", "Movies found: " + response.body().getSearch().size());
                    data.setValue(response.body().getSearch());
                } else {
                    Log.e("MovieRepository", "Error in search API response: " + response.message());
                    data.setValue(null);
                }
            }

            @Override
            public void onFailure(Call<MovieSearchResponse> call, Throwable t) {
                Log.e("MovieRepository", "Search API call failed: " + t.getMessage());
                data.setValue(null);
            }
        });
        return data;
    }

    // Method to get movie details by IMDb ID with a callback
    public void getMovieDetails(String imdbId, MovieDetailsCallback callback) {
        apiService.getMovieDetails(API_KEY, imdbId).enqueue(new Callback<Movie>() {
            @Override
            public void onResponse(Call<Movie> call, Response<Movie> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("MovieRepository", "Movie details found: " + response.body().getTitle());
                    callback.onSuccess(response.body()); // Invoke onSuccess callback
                } else {
                    Log.e("MovieRepository", "Error fetching movie details: " + response.message());
                    callback.onError("Error fetching movie details"); // Invoke onError callback
                }
            }

            @Override
            public void onFailure(Call<Movie> call, Throwable t) {
                Log.e("MovieRepository", "API call failed: " + t.getMessage());
                callback.onError("Failed to fetch movie details: " + t.getMessage()); // Invoke onError callback
            }
        });
    }
}
